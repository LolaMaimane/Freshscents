   <?php

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>FreshScents | Cart</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="Cart.css">
    <style>
        footer {
            background-color: #AFE1AF;
            text-align: center;
            padding: 10px 0;
        }
    </style>
</head>
<body>

<header>
    <div class="navbar">
        <div class="logo">
            <img src="FR  SHSCENT.jpg" width="200px" height="90px" alt="FreshScents Logo">
        </div>
        <nav>
            <ul>
                <li><a href="Home Page.php">Home</a></li>
                <li><a href="products.php">Products</a></li>
                <li><a href="AboutUs.php">About Us</a></li>
                <li><a href="ContactUs.php">Contact</a></li>
                <li><a href="Cart.php"><img src="shopping bag.jpg" width="30px" height="30px" alt="Shopping Cart"></a></li>            </ul>
        </nav>
    </div>
</header>

<!-- Cart Section -->
<section class="cart-section">
    <h1>Your Shopping Cart</h1>
    <div id="cart-items" class="cart-items">
        <?php if (empty($cart_items)): ?>
            <p>Your cart is empty.</p>
        <?php else: ?>
            <ul>
                <?php foreach ($cart_items as $item): ?>
                    <li>
                        <strong><?php echo htmlspecialchars($item['name']); ?></strong> - 
                        Quantity: <?php echo htmlspecialchars($item['quantity']); ?> - 
                        Price: $<?php echo htmlspecialchars($item['price']); ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>

   <!-- Checkout Process -->
<div class="checkout-process">
    <h2>Checkout</h2>
    <div class="checkout-step">
        <h3>Step 1: Review Items</h3>
        <p>Ensure all your items are correct.</p>
    </div>
    <div class="checkout-step">
        <h3>Step 2: Payment Information</h3>
        <form id="payment-form">
            <label for="card-number">Card Number</label>
            <input type="text" id="card-number" name="card-number" required 
                   maxlength="14" pattern="\d{14}" placeholder="Enter 14-digit card number">
            
            <label for="expiry-date">Expiry Date</label>
            <input type="text" id="expiry-date" name="expiry-date" required 
                   pattern="(0[1-9]|1[0-2])\/\d{2}" placeholder="MM/YY">
            
            <label for="cvv">CVV</label>
            <input type="text" id="cvv" name="cvv" required 
                   maxlength="3" pattern="\d{3}" placeholder="3-digit CVV">
            
            <button type="button" onclick="processPayment()">Confirm Payment</button>
        </form>
    </div>
    <div id="confirmation-message"></div>
</div>

<script>
    // JavaScript to validate and process payment
    function processPayment() {
        const cardNumber = document.getElementById('card-number');
        const expiryDate = document.getElementById('expiry-date');
        const cvv = document.getElementById('cvv');
        
        if (!cardNumber.checkValidity()) {
            alert('Please enter a valid 14-digit card number.');
            return;
        }

        if (!expiryDate.checkValidity()) {
            alert('Please enter a valid expiry date in MM/YY format.');
            return;
        }

        if (!cvv.checkValidity()) {
            alert('Please enter a valid 3-digit CVV.');
            return;
        }

        alert('Payment processed successfully!');
        // Add your payment processing logic here.
        document.getElementById('confirmation-message').innerText = 'Payment confirmed!';



       
// Simulate a list of order statuses
$order_statuses = ["Processing", "Shipped", "Out for Delivery", "Delivered"];
?>

<div class="track-order">
    <h1>Track Your Order</h1>
    <input type="text" id="order-id" placeholder="Enter your Order ID">
    <button onclick="trackOrder()">Track Order</button>
    <div id="order-status"></div>
</div>

<script>
    function trackOrder() {
        const orderId = document.getElementById('order-id').value.trim();
        const orders = JSON.parse(localStorage.getItem('orders')) || [];
        
        const order = orders.find(o => o.orderId === orderId);
        if (!order) {
            document.getElementById('order-status').innerHTML = '<p style="color:red;">Order not found!</p>';
            return;
        }

        // Simulate order status updates
        const status = order.status;

        document.getElementById('order-status').innerHTML = `
            <p><strong>Order ID:</strong> ${orderId}</p>
            <p><strong>Status:</strong> ${status}</p>
            <p><strong>Total:</strong> $${order.total.toFixed(2)}</p>
            <ul>
                ${order.items.map(item => `<li>${item.name} - Quantity: ${item.quantity}</li>`).join('')}
            </ul>
        `;
    

    }
</script>

</section>

<footer>
    <p>2024 FreshScents<br>
    Email: info@freshscents.com<br> 
    Phone: +27 13 755 2500<br>
    Office Address: 15 Kopane Bld<br> 
    Cnr President Kruger<br>
    Vanderbijlpark<br>
    1900<br>
    For all social media platforms<br>
    @freshscents_1156</p>
</footer>

<script src="cart.js"></script>
</body>
</html>